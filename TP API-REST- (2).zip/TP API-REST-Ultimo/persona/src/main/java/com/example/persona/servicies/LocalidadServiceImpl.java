package com.example.persona.servicies;


import com.example.persona.entities.Localidad;
import com.example.persona.repositories.BaseRepository;
import com.example.persona.repositories.LocalidadRepository;
import org.springframework.beans.factory.annotation.Autowired;

public class LocalidadServiceImpl extends BaseServiceImpl<Localidad, Long> implements LocalidadService{

    @Autowired
    private LocalidadRepository localidadRepository;

    public LocalidadServiceImpl(BaseRepository<Localidad, Long> baseRepository){
     super(baseRepository);
    }
}
