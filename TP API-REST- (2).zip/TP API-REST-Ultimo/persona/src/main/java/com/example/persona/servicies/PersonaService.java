package com.example.persona.servicies;

import com.example.persona.entities.Persona;

public interface PersonaService extends BaseService<Persona, Long>{

}
