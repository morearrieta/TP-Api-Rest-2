package com.example.persona.servicies;

import com.example.persona.entities.Autor;

public interface AutorService extends BaseService<Autor, Long>{
}
