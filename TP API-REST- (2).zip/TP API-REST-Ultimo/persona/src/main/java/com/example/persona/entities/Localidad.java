package com.example.persona.entities;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.envers.Audited;

import java.io.Serializable;

@Entity
@Table(name = "Localidad")
@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
@Audited

public class Localidad extends Base{

    @Column(name = "denominacion")
    private String denominacion;
}
