package com.example.persona.servicies;

import com.example.persona.entities.Localidad;

public interface LocalidadService extends BaseService<Localidad, Long>{
}
