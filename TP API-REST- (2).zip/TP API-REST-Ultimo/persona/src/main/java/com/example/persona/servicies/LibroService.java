package com.example.persona.servicies;

import com.example.persona.entities.Libro;

public interface LibroService extends BaseService<Libro, Long>{
}
