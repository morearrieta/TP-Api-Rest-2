package com.example.persona.repositories;

public interface LibroRepository {
}
